﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        WNG_Test.Helper objHelper = new WNG_Test.Helper();
        //Pass Test for Odd Numbers
        [TestMethod]
        public void TestNumbersPassSequence()
        {
           var result = objHelper.GetNumericSequences("1");
           var objSequences = new WNG_Test.Sequences();
           objSequences.Numbers = "01";
           objSequences.OddNumbers = "1";
           objSequences.EvenNumbers = "0";
           objSequences.NumbersWithCharacters = "Z1";
           objSequences.FibonacciNumbers ="01";
           NUnit.Framework.Assert.IsTrue(objSequences.Numbers == result.Numbers);
        }

        //Fail Test for Numbers
        [TestMethod]
        public void TestNumbersFailSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();
            objSequences.Numbers = "08";           
            NUnit.Framework.Assert.IsTrue(objSequences.Numbers == result.Numbers);
        }

        //Pass Test for Odd Numbers
        [TestMethod]
        public void TestOddNumbersPassSequence()
        {
            var result = objHelper.GetNumericSequences("6");
            var objSequences = new WNG_Test.Sequences();            
            objSequences.OddNumbers = "135";            
            NUnit.Framework.Assert.IsTrue(objSequences.OddNumbers == result.OddNumbers);
        }


        //Fail Test for Odd Numbers
        [TestMethod]
        public void TestOddNumbersFailSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();
            objSequences.OddNumbers = "08";
            NUnit.Framework.Assert.IsTrue(objSequences.OddNumbers == result.OddNumbers);
        }


        //Pass Test for Even Numbers
        [TestMethod]
        public void TestEvenNumbersPassSequence()
        {
            var result = objHelper.GetNumericSequences("2");
            var objSequences = new WNG_Test.Sequences();            
            objSequences.EvenNumbers = "02";
            NUnit.Framework.Assert.IsTrue(objSequences.EvenNumbers == result.EvenNumbers);
        }


        //Fail Test for Even Numbers
        [TestMethod]
        public void TestEvenNumbersFailSequence()
        {
            var result = objHelper.GetNumericSequences("5");
            var objSequences = new WNG_Test.Sequences();
            objSequences.EvenNumbers = "032";
            NUnit.Framework.Assert.IsTrue(objSequences.EvenNumbers == result.EvenNumbers);
        }


        //Pass Test for Numbers With Characters
        [TestMethod]
        public void TestNumbersWithCharactersPassSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();            
            objSequences.NumbersWithCharacters = "Z1";            
            NUnit.Framework.Assert.IsTrue(objSequences.NumbersWithCharacters == result.NumbersWithCharacters);
        }


        //Fail Test for Numbers With Characters
        [TestMethod]
        public void TestNumbersWithCharactersFailSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();
            objSequences.NumbersWithCharacters = "08";
            NUnit.Framework.Assert.IsTrue(objSequences.NumbersWithCharacters == result.NumbersWithCharacters);
        }


        //Pass Test for Fibonacci Numbers
        [TestMethod]
        public void TestFibonacciNumbersPassSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();            
            objSequences.FibonacciNumbers = "01";
            NUnit.Framework.Assert.IsTrue(objSequences.FibonacciNumbers == result.FibonacciNumbers);
        }


        //Fail Test for Fibonacci Numbers
        [TestMethod]
        public void TestFibonacciNumbersFailSequence()
        {
            var result = objHelper.GetNumericSequences("1");
            var objSequences = new WNG_Test.Sequences();
            objSequences.FibonacciNumbers = "78";
            NUnit.Framework.Assert.IsTrue(objSequences.FibonacciNumbers == result.FibonacciNumbers);
        }       
    }
}
