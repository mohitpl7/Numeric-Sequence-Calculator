﻿Inorder to run this application please fallow underlying steps.

1.Download this web application in your system.
2.Open the application in VS2013.
3.Run the application.
4.Test the application by entering any number int the textbox.
5.A numeric sequence will be generated carrying all numbers,even numbers,odd numbers, numbers with
  characters, fibonnaci series until your given number.