﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WNG_Test
{
    public class Sequences
    {
        public string Numbers {get;set;}
        public string OddNumbers { get; set; }
        public string EvenNumbers { get; set; }
        public string NumbersWithCharacters { get; set; }
        public string FibonacciNumbers { get; set; }        
    }
}